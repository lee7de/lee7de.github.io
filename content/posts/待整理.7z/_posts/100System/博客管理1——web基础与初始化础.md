---
title: 博客管理1——web基础与初始化
categories:
  - System
  - Blog Build
toc: true
date: 2022-11-09 20:50:28
tags:
    [博客搭建, Blog]    
---

搭建个人博客的解决方案围绕着写文章并发布这一核心需求展示，本质上是对费曼学习法的一种应用，将自己学到的知识讲出来，有利于对知识的深化。

完成这一件事自然有多种解决方案，经过选择，比较容易可行~~（免费白嫖且稳定）~~的方案是：`hexo+github pages`部署方案。
<!--more-->

而为了实现个人博客网站，依次解决以下问题：

一、本地部分

1. 文章编辑，在本地采用`typora`编辑器
2. 文章管理，使用`vs code`
3. 文章展示网站生成，通过`npm`管理使用`hexo`框架

二、web服务端部分

1. 本地与服务端的通信，采用`git`管理工具
2. 服务端的文章发布，利用GitHub的pages服务完成网站的部署
3. 域名注册（选）

三、知其然，也知其所以然

1. web原理
2. 网站部署原理

# 常用hexo操作

* 清除缓存等文件并重新发布网站，就可以使用自己的域名访问 Hexo 博客了：

  ```bash
  hexo clean   # 清除缓存文件等
  hexo g       # 生成页面
  hexo s       # 启动预览
  hexo d       # 部署到网络
  hexo g -w    # 可实时监测文章修改情况，结合`hexo s`实时查看页面渲染效果
  ```

---

# 本地部分的配置

## 文章编辑

这一部分关于`typora`的使用主要点有文章本身和markdown两个部分，通过对markdown语法的学习以及自身实践带动的想法驱动可以很好地解决。

## 文章展示网站的生成

> 以下命令如无特别说明，默认在`cmd`窗口下执行（在当前文件夹地址栏输入`cmd`即可调出该窗口）。

1、下载[npm](https://nodejs.org/zh-cn/)工具

2、将默认的npm源修改成腾讯云镜像源：

* 命令

```cmd
npm config set registry http://mirrors.cloud.tencent.com/npm/
```

* 验证命令

```cmd
npm config get registry
```

如果返回http://mirrors.cloud.tencent.com/npm/，说明镜像配置成功。

3、安装hexo框架并初始化博客：

1. hexo框架

```
npm install -g hexo-cli
```

2. 初始化hexo，可自定义初始化的博客发布网站文件夹，如果不定义，则使用`hexo init`命令默认在当前文件夹下。

```cmd
hexo init <folder>
cd <folder>
```

3. 在上一步hexo会从git仓库下载hexo配置文件，在工程文件夹下有个`package.json`，npm会根据此`json`文件进一步完成网站部署相关插件的下载，这些内容最终存放在`node_modules`文件夹下，使用以下命令完成相关初始化插件的安装:

```cmd
npm install
```

> 补充：这意味着你可以定制`package.json`下载你需要的内容，默认主题可以在这里设置不安装。

## 主题选配

先在本地使用hexo框架生成网页，看看效果，此处选择butterfly主题，下面的大部分内容在对应的主题官方文档都能找到。

1. 在hexo工程的根目录安装主题：

```cmd
git clone -b master https://github.com/jerryc127/hexo-theme-butterfly.git themes/butterfly
```

2. 全局主题配置。修改 `Hexo` 根目录下的 `_config.yml`，把主题改为`butterfly`，同时安装 pug 以及 stylus 的渲染器

> 全局整体的配置可参考hexo官方文档，主题特色配置参考对应主题的文档

```cmd
npm install hexo-renderer-pug hexo-renderer-stylus --save
```

3. 主题自定义配置。在 hexo 的根目录创建一个文件` _config.butterfly.yml`，并把主题目录的 `_config.yml` 内容复制到 `_config.butterfly.yml `

> Hexo会自动合併主题中的`_config.yml`和` _config.butterfly.yml`里的配置，如果存在同名配置，会使用`_config.butterfly.yml`的配置，其优先度较高。

## 文章管理与展示

选配好主题，就能写文章发布了。一般地文章放在根目录的`source/_posts`文件夹下，生成文章的模板在根目录的`scaffolds`文件夹下。

* 内容书写

大致地，hexo用得上的生成内容有两种形式，page和post。page页面下提供文章的各种呈现服务，大致有目录、文章发布时间线、文章标签、文章列表、友链、关于网站的说明等各种内容；post即对应我们写的各种文章。此过程通过`new`命令完成。

1. new后面跟的参数有layout（即page或post）和对应的标题，layout默认参数是post。

```cmd
hexo new [layout] <title>
```

​		例如，生成tags页面：

```
hexo new page tags
```

2. 输入以下命令，hexo会根据scaffolds下设置好的`post.md`模板生成标题名为`test`的文章：

```cmd
hexo new title
```

3. 主题的更多配置从[Butterfly主题页面](https://butterfly.js.org/posts/dc584b87/#%E6%A8%99%E7%B1%A4%E9%A0%81)开始。

* 内容生成

在本地电脑上完成文章的书写后，需要使用hexo命令生成展示页面，使用以下命令（可简写为`hexo g`）：

```bash
hexo generate
```

* 本地展示页面测试

开启一个本地服务器，默认可在浏览器输入`http://localhost:4000/`查看页面效果（可简写为`hexo s`）：

```bash
hexo server
```

> Tips：
>
> `hexo g -w`可实时监测文章修改情况，结合`hexo s`实时查看页面渲染效果。
>
> `hexo clean`可清除缓存和已生成的静态文件
>
> 更多拓展内容可阅读[官方文档](https://hexo.io/docs/commands)。

## 文件管理工具Git

上述完成hexo部署之后，我们接着需要配置git：

1. 下载[git](https://git-scm.com/download/win)
2. 配置ssh链接

* 注册GitHub

* 创建GitHub项目

* 安装并打开`git`，配置全局变量，`git config`可查看当前配置内容。

  ```bash
  git config --global user.name "your name" 
  git config --global user.email "your@email.com"
  ```

* 生成ssh密钥：

  ```bash
  ssh-keygen -t rsa -C "your@email.com"
  ```

* 本地用户文件的`.ssh`文件夹下会生成`id_rsa`和`id_rsa.pub`两个文件，将`id_rsa.pub`里的内容配置到GitHub账号settings的`SSH and GPG keys`中，即完成了本地和网络端的密钥安装，每次通信便可便登录进行。

> 用户文件可在地址栏输入`%userprofile%`快速进入

3. 测试ssh链接是否成功

```bash
ssh -T git@github.com
```

## 小结

经过上述准备，我们便完成了本地的基础准备：

* npm安装与换源
* hexo框架安装
* 选配合适的网站主题
* 在本地查看生成的web网站
* git下载与ssh密钥配对

# [Web服务](https://zhuanlan.zhihu.com/p/60578464)的配置

接着我们将文章发布到网络，使用上述已经配置好的git完成。

## 创建网站存储仓库

在GitHub主页创建一个`用户名.github.io`的仓库，以供本地内容上传。

## 网站部署的配置

1. 首先安装`hexo-deployer-git`：

```bash
npm install hexo-deployer-git --save
```

2. 修改 _config.yml 文件末尾的 Deployment 部分，修改成如下：

```yaml
deploy:
  type: git
  repository: git@github.com:用户名/用户名.github.io.git
  branch: master
```

3. 部署命令:

```bash
hexo d
```

## 域名注册与绑定（选）

通过上述步骤，我们就能用`用户名.github.io`来访问搭建好的网站。这一名称还可以更自主一些，即注册更简单形象的域名链接到`github pages`。

* 注册并解析域名之后，在 DNS 设置部分，删除自带的记录，然后添加 CNAME 记录将 www 域名解析指向 `用户名.github.io`
* 本地博客文件夹的 source 目录，打开记事本，里面输入自己的域名，如 http://www.example.com，保存名称为 “CNAME”，格式为 “所有文件”（无 .txt 后缀）

## 小结
经过上述准备，我们便完成了web服务端的配置：
* GitHub仓库的建立
* 本地git部署与git上传
* 域名（选）

# 拓展：Blog Web 基本原理

## Web页面

Web网页基本组成是HTML+CSS+JavaScript，这一部分可以到[MDN官方Web入门手册](https://developer.mozilla.org/zh-CN/docs/Learn/Getting_started_with_the_web)去学习。其中，

* HTML是一种超文本标记语言 。**H**yper**t**ext **M**arkup **L**anguage，是一种用来结构化 Web 网页及其内容的标记语言，网页内容可以是：一组段落、一个重点信息列表、也可以含有图片和数据表。总而言之，它是所有要表达内容的集合体。

* CSS是层叠样式表。**C**ascading **S**tyle **S**heet，是为网页添加样式的代码。通过CSS学习将文本设置为黑色或红色、将内容显示在屏幕的特定位置、用背景图片或颜色来装饰网页等内容。

* JavaScript 是一门编程语言。可为网站添加交互功能（例如：游戏、动态样式、动画以及在按下按钮或收到表单数据时做出的响应等）。

## 框架

单纯使用上述的web基本语言写一些复杂的页面是一件费时费力的工作，我们使用框架加快构建 web 站点或应用程序的过程。hexo算是一个生成静态页面的框架，特别用于写博客上。

## 页面渲染与发布

通过web框架生成页面并整理好网站相关的全部文件后，接着是将网页发布到服务器上，这样所有人就能看到。

大体上，web网页的渲染分为静态页面和脚本实时渲染两种，我们这里的博客网站即是生成了静态页面。所采取的方案是将生成的静态页面发布到[GitHub](https://github.com/)。这里交互原理如下：

* 对于连接到互联网的计算机，分别承担客户端和服务器两种功能。

* 客户端`CLIENT`是典型的 Web 用户入网设备（比如，你连接了 Wi-Fi 的电脑，或接入移动网络的手机）和设备上可联网的软件（通常使用像 Firefox 和 Chrome 的浏览器）
* 服务器`SERVER`是存储网页，站点和应用的计算机。当一个客户端设备想要获取一个网页时，一份网页的拷贝将从服务器上下载到客户端机器上来在用户浏览器上显示。

![Web原理](/img/post/web/simple-client-server.png)

整个过程，发生如下行为：

1.  浏览器在域名系统（DNS）服务器上找出存放网页的服务器的实际地址。
2.  浏览器发送 HTTP 请求信息到服务器来请拷贝一份网页到客户端。这条消息，包括其他所有在客户端和服务器之间传递的数据都是通过互联网使用 TCP/IP 协议传输的。
3.  服务器同意客户端的请求后，会返回一个“200 OK”信息，意味着“你可以查看这个网页，给你”，然后开始将网页的文件以数据包的形式传输到浏览器。
4.  浏览器将数据包聚集成完整的网页然后将网页呈现给你。

## 博客文章的发布原理

对应上述原理，在本地撰写 Markdown 格式文章后，通过 Hexo 解析文档，渲染生成具有主题样式的 HTML 静态网页，再推送到 GitHub 上完成博文的发布。

其中，

* GitHub 官方提供了GitHub Pages 服务，可以免费托管静态站点，对应上面的服务器`SERVER`。

* Hexo 是一个快速、简洁且高效的静态博客框架，基于 Node.js 运行，可以将我们撰写的 Markdown 文档解析渲染成静态的 HTML 网页，对应上面的客户端`CLIENT`。
* 来自知乎的图片非常形象：

![文章发布原理](/img/post/web/post-hexo.jpg)


# More

* 文章页面、发布时间线、标签关键词、内容分类、关于以及全局搜索，目前来讲这么一个内容导向性的文章足够了，更多拓展的模块是友链、站外链接之类的了
* 搭建使用图床、数学公式支持，使得文章表现力更强
* 技术力更强的时候或许再考虑自己搭建服务器部署网站，提供更多服务方便自己和别人，同时还有一些统计功能、SEO优化、更好的前端设计等都是可以做的。（好大大大的坑）

# 资源链接与参考内容

一、相关设置

【1】[npm使用国内镜像加速的几种方法](https://cloud.tencent.com/developer/article/1372949)

【2】[使用 Hexo+GitHub 搭建个人免费博客教程（小白向）](https://zhuanlan.zhihu.com/p/60578464)

二、hexo相关

【1】[hexo官方文档](https://hexo.io/docs/)

【2】[hexo设置多标签](https://www.zhihu.com/question/48934747/answer/113403121)

三、主题配置

【1】[Butterfly 安装文档(一) 快速开始](https://butterfly.js.org/posts/21cfbf15/)

四、web开发相关

【1】[Web MDN 开发手册](https://developer.mozilla.org/zh-CN/docs/Learn/Getting_started_with_the_web)

【2】[菜鸟教程 HTML教程](https://www.runoob.com/html/html-tutorial.html)

