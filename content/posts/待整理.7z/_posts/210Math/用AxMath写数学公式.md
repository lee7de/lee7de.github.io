---
title: 常用数学公式编辑语法
date: 2021-06-14 17:14:32
categories:
    - Math
    - Engineering Math
    - AxMath-Latex 
tags:
    AxMath
---
用AxMath编辑数学公式

<!--more-->

# 不等关系

*   $\ge$：`\ge`

*   $\le$：`\le`

# 微积分运算

*   极限 $\underset{n\rightarrow \infty}{\lim}x_n=A$：`\underset{n\rightarrow \infty}{\lim}x_n=A`
